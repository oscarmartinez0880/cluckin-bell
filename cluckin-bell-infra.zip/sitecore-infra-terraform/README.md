# Sitecore Infra Terraform (Modular, Multi-Environment)

This repository provisions all AWS infrastructure required for the Kubernetes-based Sitecore project (cfacom-sitecore), using a modular, environment-driven approach. Each service (EKS, VPC, RDS, EFS, ElastiCache, ECR, WAF, IAM, Monitoring) is fully modular and supports dev/qa/prod isolation.

---

## Directory Structure

```
sitecore-infra-terraform/
├── modules/
│   ├── vpc/
│   ├── eks/
│   ├── rds/
│   ├── elasticache/
│   ├── efs/
│   ├── ecr/
│   ├── iam/
│   ├── waf/
│   └── monitoring/
├── envs/
│   ├── dev/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── terraform.tfvars
│   │   ├── backend.tf
│   ├── qa/
│   │   └── ...
│   ├── prod/
│   │   └── ...
├── global-variables.tf
└── README.md
```

---

## Quickstart

1. `cd envs/dev` (or qa/prod)
2. `terraform init`
3. `terraform apply -var-file=terraform.tfvars`
4. Use the outputs to configure the Kubernetes and Helm deployment.

---

## Module Overview

- `modules/vpc/`: VPC, subnets, NAT, IGW, route tables, security groups.
- `modules/eks/`: EKS cluster, node groups, OIDC provider, IRSA roles.
- `modules/rds/`: SQL Server (or other) RDS instance and subnet group.
- `modules/efs/`: EFS filesystem and mount targets.
- `modules/elasticache/`: Redis/ElastiCache cluster.
- `modules/ecr/`: ECR repositories for Sitecore images.
- `modules/iam/`: IAM roles/users/policies for K8s, CI/CD, and IRSA.
- `modules/waf/`: AWS WAFv2 WebACL and associations for ALB.
- `modules/monitoring/`: Prometheus/Grafana storage, IAM, and KMS if needed.

---

## Environments

Each environment (`dev`, `qa`, `prod`) uses its own directory, tfvars, and remote state.

---

## Outputs

All environment outputs (EKS cluster name, kubeconfig, RDS endpoint, ElastiCache endpoint, ECR URLs, IRSA ARNs, WAF ARNs) are available for use in K8s/Helm manifests and CI/CD.

---