# Building and Managing Docker Images for Sitecore Kubernetes

This document explains how to build, customize, and manage all Docker images used in this Sitecore Kubernetes project.

---

## 1. Overview

You need Docker images for:

- **Sitecore Content Management (CM)**
- **Sitecore Content Delivery (CD)**
- (Optional) Custom Solr if needed
- Supporting services (Solr, Redis) default to public images unless customized

---

## 2. Directory Structure

All custom Dockerfiles and build context are in the `docker/` directory:

```
docker/
  sitecore-cm/
    Dockerfile
    App_Config/
    custom-modules/
    wwwroot/assets/
  sitecore-cd/
    Dockerfile
    App_Config/
    custom-modules/
    wwwroot/assets/
  solr-custom/
    Dockerfile  # Only if you need a custom Solr
```

---

## 3. Building Sitecore Images

### Step 1: Authenticate to Sitecore Container Registry

```bash
docker login scr.sitecore.com -u <sitecore_username> -p <sitecore_password>
```

### Step 2: Build the Images

```bash
docker build -t <your_ecr_repo>/sitecore-cm:10.4.0 -f docker/sitecore-cm/Dockerfile docker/sitecore-cm
docker build -t <your_ecr_repo>/sitecore-cd:10.4.0 -f docker/sitecore-cd/Dockerfile docker/sitecore-cd
```

### Step 3: Push to AWS ECR

```bash
aws ecr get-login-password --region <region> | docker login --username AWS --password-stdin <your_ecr_repo>
docker push <your_ecr_repo>/sitecore-cm:10.4.0
docker push <your_ecr_repo>/sitecore-cd:10.4.0
```

---

## 4. Customizing Your Images

- Add custom configs, DLLs, or modules to `App_Config/`, `custom-modules/`, etc.
- Edit the Dockerfile to COPY new folders/files as needed.
- Change the `ENV ASPNETCORE_ENVIRONMENT` for environment-specific logic.

---

## 5. Using Images in Kubernetes

- Reference the pushed ECR URLs and tags in your Helm values and K8s manifests:
    ```yaml
    image:
      repository: <your_ecr_repo>/sitecore-cm
      tag: "10.4.0"
    ```

---

## 6. Rollbacks

- To roll back, update the Helm values or manifest with an earlier Docker image tag and redeploy.
- You can also use Helm’s built-in rollback commands.

---

## 7. Related Files

- See `docker/sitecore-cm/Dockerfile` and `docker/sitecore-cd/Dockerfile` for detailed build examples.
- For custom Solr, see `docker/solr-custom/Dockerfile`.

---

**All Docker build context and Dockerfiles should always be versioned in this repo, under `docker/`, for traceable and repeatable builds.**