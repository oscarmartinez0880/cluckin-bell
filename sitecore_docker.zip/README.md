# Sitecore Migration to Kubernetes (cfacom-sitecore)

This repository contains the **complete, production-grade** Kubernetes and monitoring setup for Sitecore 10.4 XP Scaled on AWS EKS, supporting `dev`, `qa`, and `prod` environments. It is designed to be paired with a modular Terraform infrastructure repository (see the migration guide for details).

---

## Structure

- `docker/`: **All custom Dockerfiles and build context** for Sitecore roles (CM, CD, etc).
- `k8s/{dev,qa,prod}/`: All Kubernetes manifests for each environment.
- `helm/`: Helm values per environment and role.
- `k8s-monitoring/`: Full Prometheus+Grafana monitoring stack and dashboards.
- `README.md`: Project overview and structure.
- `README_DEPLOY.md`: Complete step-by-step deployment process, including Docker build & push.
- `README_DEPLOY_DOCKER.md`: Full Docker image management instructions.
- `README_PLAN.md`: Comprehensive migration plan and file-by-file explanation.

---

## Quickstart

1. **Build Docker images** for Sitecore CM/CD (see [README_DEPLOY_DOCKER.md](README_DEPLOY_DOCKER.md) below).
2. Apply infra with [sitecore-infra-terraform](https://github.com/your-org/sitecore-infra-terraform).
3. Update secrets and values files with your actual endpoints, ARNs, etc.
4. Deploy manifests & Helm releases per environment.
5. Set up monitoring and dashboards.

---

## Docker Images: Build & Push

See [README_DEPLOY_DOCKER.md](README_DEPLOY_DOCKER.md) for full details.

---

## Documentation

- **[README_PLAN.md](README_PLAN.md):** Migration plan, architecture, and detailed file explanations.
- **[README_DEPLOY.md](README_DEPLOY.md):** Step-by-step deployment guide (Docker, Terraform, K8s, Helm).
- **[README_DEPLOY_DOCKER.md](README_DEPLOY_DOCKER.md):** How to build, customize, and manage Docker images for this project.

---

## Supporting Images

- **Solr:** Default: `solr:8.11` (see `k8s/dev/solr-statefulset.yaml`). Use a custom build (see `docker/solr-custom/Dockerfile`) only if you have plugins.
- **Redis:** Default: `redis:7`. No Dockerfile needed unless customized.

---

## Customization

- Place your custom configs, modules, or assets in the respective `docker/sitecore-cm/` and `docker/sitecore-cd/` folders.
- Edit Dockerfiles as needed for your solution.

---