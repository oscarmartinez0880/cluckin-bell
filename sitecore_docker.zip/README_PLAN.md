# Sitecore Kubernetes Project: Migration Plan & File-by-File Explanation

This document covers:

- The complete **migration plan** for Sitecore on AWS EKS (containers).
- File-by-file explanations for all resources in this repository, including Dockerfiles.

---

## 1. Architecture Overview

- **EKS** runs Sitecore CM, CD, and supporting services.
- **Docker images** for CM and CD are built from official Sitecore base images, with customizations, and stored in ECR.
- **Terraform** (in a separate repo) provisions all infra: VPC, EKS, RDS, EFS, ElastiCache, ECR, WAF, etc.
- **Kubernetes** manifests and Helm charts deploy Sitecore and supporting workloads.
- **Prometheus/Grafana** provide monitoring.
- **Multi-environment:** Each of dev, qa, prod is isolated by namespace, configuration, and infra.

---

## 2. Directory Structure & File Explanations

### docker/

**Purpose:** Holds all custom Dockerfiles and their build context for Sitecore images.

- `docker/sitecore-cm/Dockerfile`: Builds the Sitecore Content Management (CM) image from the official base.  
  - Custom configs, modules, assets: place in `App_Config/`, `custom-modules/`, `wwwroot/assets/`.
- `docker/sitecore-cd/Dockerfile`: Builds the Sitecore Content Delivery (CD) image from the official base.
  - Custom configs, modules, assets: as above.
- `docker/solr-custom/Dockerfile`: (Optional) Use if you need a custom Solr image with plugins/config.

---

### k8s/{dev,qa,prod}/

**Purpose:** All Kubernetes manifests, by environment.

- `namespace.yaml`: Creates the namespace for isolation.
- `rbac.yaml`: ServiceAccount and RBAC for Sitecore workloads (including IRSA for AWS access).
- `secrets.yaml`: K8s secrets for DB, Solr, Redis connection strings (base64-encoded).
- `configmap.yaml`: Non-sensitive config (env, log level, etc).
- `sitecore-cm-deployment.yaml`: Deploys Sitecore CM using the custom Docker image.
- `sitecore-cm-service.yaml`: Internal K8s service for CM.
- `sitecore-cm-ingress.yaml`: ALB ingress for public access; integrates with AWS WAF (via ALB).
- `sitecore-cd-deployment.yaml`, `sitecore-cd-service.yaml`, `sitecore-cd-ingress.yaml`: Analogous for CD.
- `solr-statefulset.yaml`, `solr-service.yaml`: (Default: official Solr image, or custom if built) Used for dev/qa.
- `redis-deployment.yaml`, `redis-service.yaml`: In-cluster Redis for dev/qa; prod uses AWS ElastiCache.

---

### helm/

**Purpose:** Helm values files for each environment & role.

- `sitecore-cm-values-dev.yaml`, `sitecore-cd-values-dev.yaml`: Dev Helm values (image, endpoints, etc).
- `sitecore-cm-values-qa.yaml`, `sitecore-cd-values-qa.yaml`: QA values.
- `sitecore-cm-values-prod.yaml`, `sitecore-cd-values-prod.yaml`: Prod values.

---

### k8s-monitoring/

**Purpose:** Monitoring stack for all environments.

- `monitoring-namespace.yaml`: Namespace for Prometheus/Grafana.
- `prometheus/prometheus-values.yaml`: Prometheus Helm values (scraping config, retention, etc).
- `grafana/grafana-values.yaml`: Grafana Helm values and persistence.
- `grafana/dashboards/*.json`: Prebuilt dashboards for Sitecore, K8s, AWS infra, and supporting services.

---

### README.md

- **Project structure, build & deployment overview, and documentation links.**

### README_DEPLOY.md

- **Step-by-step guide for Docker image build, infra deployment (Terraform), and app deployment (K8s/Helm).**

### README_DEPLOY_DOCKER.md

- **Complete Docker image build and management documentation.**

---

## 3. How Dockerfiles Integrate

- Custom Dockerfiles are built and pushed to AWS ECR.
- Image URLs/tags are referenced in K8s manifests and Helm values.
- GitHub Actions (or other CI/CD) can build, tag, and push images as part of pipeline.
- Storing Dockerfiles in this repo keeps all application build/deploy logic together.

---

## 4. WAF Handling

- WAF is managed via Terraform and attached to the ALB created by K8s Ingress.
- No WAF config is present in K8s manifests; all is applied at the infra layer.

---

## 5. Summary Table

| File/Folder         | Purpose                                                  | Sitecore/AWS/Grafana/Prometheus Relation                      |
|---------------------|---------------------------------------------------------|---------------------------------------------------------------|
| docker/             | Custom Dockerfiles & build context for Sitecore images  | Builds/pushes images to ECR; referenced in K8s/Helm           |
| k8s/                | K8s manifests per env (dev/qa/prod)                     | Deploys Sitecore, Solr, Redis, CM/CD, ingress, RBAC, secrets  |
| helm/               | Helm values per env/role                                | Parameterizes image, endpoints, config for repeatable deploys  |
| k8s-monitoring/     | Monitoring: Prometheus, Grafana, dashboards             | EKS, Sitecore, infra metrics and alerting                     |
| README.md           | Project structure & overview                            | Entry point documentation                                     |
| README_DEPLOY.md    | Step-by-step deployment guide                           | End-to-end: Docker, Terraform, K8s, Helm                      |
| README_DEPLOY_DOCKER.md | Docker image management & customization             | Building, pushing, and referencing custom images              |
| README_PLAN.md      | Migration plan and file explanations                    | Full reference for onboarding and audit                       |

---

**For detailed build/deploy steps, see [README_DEPLOY.md](README_DEPLOY.md). For Docker image details, see [README_DEPLOY_DOCKER.md](README_DEPLOY_DOCKER.md).**

---