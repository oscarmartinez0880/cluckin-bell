# Sitecore Infrastructure & Kubernetes Deployment Guide

This guide provides **step-by-step instructions** for building Docker images, deploying the Sitecore infrastructure (Terraform), and application workloads (Kubernetes/Helm) for each environment: `dev`, `qa`, and `prod`.

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Docker Image Build & Push](#2-docker-image-build--push)
3. [Terraform Deployment (Infrastructure)](#3-terraform-deployment-infrastructure)
4. [Kubernetes & Helm Deployment (Application)](#4-kubernetes--helm-deployment-application)
5. [Switching Environments](#5-switching-environments)
6. [Rollback Procedures](#6-rollback-procedures)
7. [Appendix: Useful Commands](#7-appendix-useful-commands)

---

## 1. Prerequisites

- AWS CLI, kubectl, helm, and Docker installed.
- Valid AWS credentials (`aws configure`).
- Access to both the infra (`sitecore-infra-terraform`) and k8s (`cfacom-sitecore`) repos.
- Sitecore container registry credentials.
- ECR repositories created by Terraform infra.

---

## 2. Docker Image Build & Push

### Step 1: Authenticate to Sitecore Container Registry

```bash
docker login scr.sitecore.com -u <sitecore_username> -p <sitecore_password>
```

### Step 2: Build Images

```bash
docker build -t <your_ecr_repo>/sitecore-cm:10.4.0 -f docker/sitecore-cm/Dockerfile docker/sitecore-cm
docker build -t <your_ecr_repo>/sitecore-cd:10.4.0 -f docker/sitecore-cd/Dockerfile docker/sitecore-cd
```

> **Tip:** Update your `Dockerfile` and build context (custom App_Config, modules, etc.) as needed for each role.

### Step 3: Push to AWS ECR

```bash
aws ecr get-login-password --region <region> | docker login --username AWS --password-stdin <your_ecr_repo>
docker push <your_ecr_repo>/sitecore-cm:10.4.0
docker push <your_ecr_repo>/sitecore-cd:10.4.0
```

Repeat for new image versions as needed.

---

## 3. Terraform Deployment (Infrastructure)

**Repeat the following steps in each environment: `envs/dev`, `envs/qa`, `envs/prod`.**

### 3.1. Initialize and Plan

```bash
cd sitecore-infra-terraform/envs/<env>   # Replace <env> with dev, qa, or prod

terraform init
terraform plan -var-file=terraform.tfvars
```

### 3.2. Apply Infrastructure

```bash
terraform apply -var-file=terraform.tfvars
# Review the plan, then approve to proceed
```

### 3.3. Retrieve Outputs

After successful apply, note the outputs:
- EKS cluster name and endpoint
- kubeconfig
- RDS/ElastiCache endpoints
- ECR repo URLs
- EFS ID
- IRSA role ARN
- WAF ARN

Copy these for use in K8s/Helm deployments and Docker pushes.

---

## 4. Kubernetes & Helm Deployment (Application)

### 4.1. Update K8s Manifests & Helm Values

- Edit files in `cfacom-sitecore/k8s/<env>/` and `cfacom-sitecore/helm/` as needed:
    - Fill in outputs for endpoints, ARNs, repo URLs, etc.
    - Update image tags in Helm values to match your just-built/pushed Docker images.
    - Encode secrets (e.g., connection strings) in base64 for Kubernetes Secrets.

### 4.2. Connect kubectl to EKS

```bash
aws eks update-kubeconfig --name <eks_cluster_name> --region <aws_region>
kubectl config use-context <new-context-name> # optional
```

### 4.3. Deploy Namespaces and RBAC

```bash
kubectl apply -f k8s/<env>/namespace.yaml
kubectl apply -f k8s/<env>/rbac.yaml
```

### 4.4. Apply Secrets and ConfigMaps

```bash
kubectl apply -f k8s/<env>/secrets.yaml
kubectl apply -f k8s/<env>/configmap.yaml
```

### 4.5. Deploy Supporting Services (Solr, Redis)

```bash
kubectl apply -f k8s/<env>/solr-statefulset.yaml
kubectl apply -f k8s/<env>/solr-service.yaml
kubectl apply -f k8s/<env>/redis-deployment.yaml
kubectl apply -f k8s/<env>/redis-service.yaml
```
*(For prod, point Sitecore to AWS ElastiCache endpoint instead of in-cluster Redis.)*

### 4.6. Deploy Sitecore (Helm/Manifests)

**A. With Helm (recommended):**
```bash
helm upgrade --install sitecore-cm ./helm/sitecore-cm \
  -n <env> -f helm/sitecore-cm-values-<env>.yaml

helm upgrade --install sitecore-cd ./helm/sitecore-cd \
  -n <env> -f helm/sitecore-cd-values-<env>.yaml
```
**B. Or with raw manifests:**
```bash
kubectl apply -f k8s/<env>/sitecore-cm-deployment.yaml
kubectl apply -f k8s/<env>/sitecore-cm-service.yaml
kubectl apply -f k8s/<env>/sitecore-cd-deployment.yaml
kubectl apply -f k8s/<env>/sitecore-cd-service.yaml
```

### 4.7. Setup Ingress and DNS

```bash
kubectl apply -f k8s/<env>/sitecore-cm-ingress.yaml
kubectl apply -f k8s/<env>/sitecore-cd-ingress.yaml
```
- Obtain the ALB DNS name from `kubectl get ingress -n <env>`.
- Update Route53 CNAME records for your CM/CD URLs to this ALB DNS.

### 4.8. Deploy Monitoring (Prometheus & Grafana)

```bash
kubectl apply -f k8s-monitoring/monitoring-namespace.yaml

# Prometheus & Grafana via Helm
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm upgrade --install monitoring prometheus-community/kube-prometheus-stack \
  -n monitoring -f k8s-monitoring/prometheus/prometheus-values.yaml

helm repo add grafana https://grafana.github.io/helm-charts
helm upgrade --install grafana grafana/grafana \
  -n monitoring -f k8s-monitoring/grafana/grafana-values.yaml

# Dashboards will auto-import if placed in k8s-monitoring/grafana/dashboards/
```

---

## 5. Switching Environments

To deploy or manage a different environment, repeat the above steps in its respective `envs/<env>` or `k8s/<env>` folder and update kubeconfig accordingly.

---

## 6. Rollback Procedures

- **Docker:**  
  - Revert to a previous image tag in your Helm values file and redeploy.
  - Or pull an earlier build from ECR.

- **Terraform:**  
  - Use `terraform state list` and `terraform apply` to revert to previous state.
  - Restore from S3 state backup if needed.

- **Application:**  
  - For Helm:  
    ```bash
    helm rollback sitecore-cm <REVISION> -n <env>
    ```
  - For K8s:  
    ```bash
    kubectl rollout undo deployment/sitecore-cm -n <env>
    ```
  - For RDS/EFS: Restore from last backup or snapshot.
  - For DNS: Revert Route53 CNAMEs to previous ALB/ELB.

---

## 7. Appendix: Useful Commands

```bash
# Docker build & push
docker build -t <your_ecr_repo>/sitecore-cm:10.4.0 -f docker/sitecore-cm/Dockerfile docker/sitecore-cm
docker push <your_ecr_repo>/sitecore-cm:10.4.0

# List all resources in a namespace
kubectl get all -n <env>

# View logs
kubectl logs -n <env> <pod>

# Port-forward Grafana
kubectl port-forward svc/grafana -n monitoring 3000:80

# Helm release history
helm history sitecore-cm -n <env>
```

---

**Repeat all steps for each environment—dev, qa, prod—using the correct variable files and endpoint/config replacements. Always validate in dev before promoting to qa and prod.**